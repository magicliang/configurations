#parse("AntIDE_alipay_file_comment.java")
#if (${PACKAGE_NAME} && ${PACKAGE_NAME} != "")package ${PACKAGE_NAME};#end
#parse("AntIDE_alipay_file_header.java")
public enum ${NAME} {
}