
/**
* project name: ${PROJECT_NAME}
*
* description: ${description}
*
* @author ${USER}
*
* date: ${YEAR}-${MONTH}-${DAY} ${HOUR}:${MINUTE}
*/